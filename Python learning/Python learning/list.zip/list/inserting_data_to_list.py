#it is the ways with which we can insert the data into a list in different way.


fruits=[]    #empty list
print(fruits)


#append method --> ..............
fruits.append("Apple")
print(fruits)
fruits.append("banana")
print(fruits)

fruits.append("Guava")
print(fruits)


#insert method 
friends=["sita","james","ishan"]  #empty  list
print(friends)
friends.insert(2,"ram")
print(friends)

