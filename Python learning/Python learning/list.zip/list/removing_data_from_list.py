#removing data from list 


# 1. 'del' statement
numbers=[1,2,3,4,5,6,7]
print(numbers)
del numbers[4]
print(numbers)

#2. pop method
city=["ktm","mumbai","new york","ottowa"]
print(city)
city.pop()
print(city)

#3. remove method

names=["ram","sita","gita","rita"]
print(names)
names.remove("ram")
print(names)