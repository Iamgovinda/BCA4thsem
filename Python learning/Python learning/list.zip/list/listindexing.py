
#list indexing is the method of accessing the data inside the particular index of that list

my_list = [1,2,3,4,"Hello","World","!"]

#accesing these data inside list
print(my_list[0])
print(my_list[1])
print(my_list[2])
print(my_list[3])
print(my_list[4])
print(my_list[5])
print(my_list[6])

#negative indexing---accessing the data from last index of the list 
#negative indexing starts from -1

print(my_list[-1])
print(my_list[-2])
print(my_list[-3])
print(my_list[-4])
print(my_list[-5])
print(my_list[-6])
print(my_list[-7])







