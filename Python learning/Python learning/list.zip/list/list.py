#list is a mutable datatype in python which is used to store required data in it.

#creating a simple list
#list of integer
numbers=[1,2,3,4,5]
print(numbers)

#list of floats
floats=[1.2,1.2,1.3]
print(floats)

#list string
strings =["hello","this","is","a","string"]
print(strings)

#list of lists which is a nested list
nestedlist=[[1,2,3],[1.2,1.3,1.4],["hello","world"]]
print(nestedlist)

#mixed list 
mixeddata=[1,2,3,1.2,3.4,"string"]
print(mixeddata)


