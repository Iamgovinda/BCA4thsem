<?php
	require_once './includes/dbconfig.php';
	require_once './includes/helper.php';

	$sql = "SELECT s.id, s.roll_no, CONCAT(s.fname, ' ', s.mname, ' ', s.lname) as student_name, s.gender, CONCAT(d1.district_en, ', ', p1.province_en) AS permanent_address, CONCAT(d2.district_en, ', ', p2.province_en) AS temporary_address 
	FROM student s LEFT JOIN district d1 ON s.permanent_district_id = d1.id LEFT JOIN district d2 ON s.temporary_district_id = d2.id LEFT JOIN province p1 ON d1.province_id = p1.id LEFT JOIN province p2 ON d2.province_id = p2.id ";
	
	$data = SelectQuery($sql);
?>	

<!DOCTYPE html>
<html>
	<head>
		<title>Student List</title>
	</head>
	<body>
		<?php include('./includes/menu.php'); ?>
		<table border="1">
			<tr>
				<td>Roll No</td>  
				<td>Student Name</td>
				<td>Gender</td>
				<td>Permanent Address</td>
				<td>Temporary Address</td>
				<td>Modify Record</td>
			</tr>
			<?php 
			
			foreach ($data as $row) { ?>
                <tr>
                	<td align="center"><?php echo $row['roll_no']; ?></td>
					<td><?php echo $row['student_name']; ?></td>
					<td><?php echo $row['gender']; ?></td>
					<td><?php echo $row['permanent_address']; ?></td>
					<td><?php echo $row['temporary_address']; ?></td>
					<td align="center">
						<a href="http://localhost/kccs1/AddEditStudent.php?id=<?php echo $row['id']; ?>">Edit</a>
					</td>
                </tr>
            <?php } ?>
				
		</table>
	</body>
</html>