<?php
	require_once 'dbconfig.php';

	function LoadDistrictCombo(){
		$str = "<option value='0'>Not Defined</option>";
	    $sql = "SELECT * FROM district";
	    $data = SelectQuery($sql);
	    foreach ($data as $row) {
	    	$str .= "<option value='".$row['id']."'>".$row['district_en']."</option>";
        }
		echo $str;
	}

	function SelectQuery($sql = ""){
		$data = null;
		if($sql != ""){
			global $host; global $dbname; global $username; global $password;
			try {			
			    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
			    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			    $data = $pdo->query($sql)->fetchAll();
			} catch (PDOException $e) {
			    die("Could not connect to the database $dbname :" . $e->getMessage());
			} finally {
				$conn = null;
			}
		}
		return $data;
	}

	function ActionQuery($sql=""){
		$retValue = false;
		if($sql != ""){
			global $host; global $dbname; global $username; global $password;
			try {
				$pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
				$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$pdo->exec($sql);
				$retValue = true;
			} catch(PDOException $e) {
				echo $sql . "<br>" . $e->getMessage();
			} finally {
				$pdo = null;
			}
		}
		return $retValue;
	}
?>