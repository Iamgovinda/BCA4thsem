<a href="http://localhost/kccs1/index.php">Home</a> &nbsp;&nbsp;|&nbsp;&nbsp;

<a href="http://localhost/kccs1/StudentList.php">Student List</a> &nbsp;&nbsp;|&nbsp;&nbsp;

<a href="http://localhost/kccs1/AddEditStudent.php?id=0">Add Student</a> &nbsp;&nbsp;|&nbsp;&nbsp;

<a href="http://localhost/kccs1/ContactList.php">Contact List</a> &nbsp;&nbsp;|&nbsp;&nbsp;

<a href="http://localhost/kccs1/ContactType.php">Contact Type</a> &nbsp;&nbsp;|&nbsp;&nbsp;

<a href="http://localhost/kccs1/DistrictList.php">Districts of Nepal</a> &nbsp;&nbsp;|&nbsp;&nbsp;

<a href="http://localhost/kccs1/ProvinceList.php">Province of Nepal</a>

<br /><br /><br />