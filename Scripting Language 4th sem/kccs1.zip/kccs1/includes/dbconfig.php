<?php

	$host = "localhost";
	$dbname = "kccs";
	$username = "root";
	$password = "";


	$myRollNo = "10";

?>