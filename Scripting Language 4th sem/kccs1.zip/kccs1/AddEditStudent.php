<?php
	require_once './includes/dbconfig.php';
	require_once './includes/helper.php';

	$id = 0;
	$iId = 0; $RollNo = "0"; $FName = ""; $MName = ""; $LName = ""; $DOB = ""; $Gender = ""; $PAddress = ""; $PDistrictID = 0; $TAddress = ""; 
	$TDistrictID = 0; $Remarks = "";

	//This is executed where we want to edit student
	if(isset($_GET['id'])){		
		$id = $_GET['id'];
		if($id>0){
			$sql = "SELECT * FROM student WHERE id=$id";
			$data = SelectQuery($sql);
			$row = $data[0];

			$iId = $row['id']; 
			$RollNo = $row['roll_no']; 
			$FName = $row['fname']; 
			$MName = $row['mname']; 
			$LName = $row['lname']; 
			$DOB = $row['dob']; 
			$Gender = $row['gender']; 
			$PAddress = $row['permanent_address']; 
			$PDistrictID = $row['permanent_district_id']; 
			$TAddress = $row['temporary_address'];
			$TDistrictID = $row['temporary_district_id']; 
			$Remarks = $row['remarks'];
		}		
	}


	

	if(isset($_POST['txtID'])){
		$iId = $_POST['txtID'];
		$RollNo = $_POST['txtRollNo'];
		$FName = $_POST['txtFName'];
		$MName = $_POST['txtMName'];
		$LName = $_POST['txtLName'];
		$DOB = $_POST['txtDOB'];
		$Gender = $_POST['txtGender'];
		$PAddress = $_POST['txtPAddress'];
		$PDistrictID = $_POST['txtPDistrict'];
		$TAddress = $_POST['txtTAddress'];
		$TDistrictID = $_POST['txtTDistrict'];
		$Remarks = $_POST['txtRemarks'];


		$sql = "UPDATE student SET roll_no='$RollNo', fname = '$FName', mname = '$MName', lname = '$LName', dob = '$DOB', 
		gender = '$Gender', permanent_address = '$PAddress', permanent_district_id = '$PDistrictID', 
		temporary_address = '$TAddress', temporary_district_id = '$TDistrictID', remarks = '$Remarks' 
		WHERE id=$iId";

		if($iId==0){
			$sql = "INSERT INTO student (id, roll_no, fname, mname, lname, dob, gender, permanent_address, permanent_district_id, temporary_address, temporary_district_id, remarks) VALUES (null, '$RollNo', '$FName', '$MName', '$LName', '$DOB', '$Gender', '$PAddress', '$PDistrictID', '$TAddress', '$TDistrictID', '$Remarks')";
		}

		ActionQuery($sql);
		header("Location: http://localhost/kccs1/StudentList.php");
		die();
	}


?>

<!DOCTYPE html>
<html>
	<head>
		<title>Student List</title>
	</head>
	<body>
		<h1>Edit Student</h1>
		<form method="POST" action="">
			<input type="hidden" name = "txtID" value="<?php echo $iId; ?>">
			<table width="60%">
				<tr>
					<td width="20%">Roll No</td>
					<td width="80%"><input type="text" name="txtRollNo" value="<?php echo $RollNo; ?>"></td>
				</tr>
				<tr>
					<td>First Name</td>
					<td><input type="text" name="txtFName" value="<?php echo $FName; ?>"></td>
				</tr>
				<tr>
					<td>Middle Name</td>
					<td><input type="text" name="txtMName" value="<?php echo $MName; ?>"></td>
				</tr>
				<tr>
					<td>Last Name</td>
					<td><input type="text" name="txtLName" value="<?php echo $LName; ?>"></td>
				</tr>
				<tr>
					<td>Date of Birth</td>
					<td><input type="text" name="txtDOB" value="<?php echo $DOB; ?>"></td>
				</tr>
				<tr>
					<td>Gender</td>
					<td><input type="text" name="txtGender" value="<?php echo $Gender; ?>"></td>
				</tr>
				<tr>
					<td>Permanent Address</td>
					<td><input type="text" name="txtPAddress" value="<?php echo $PAddress; ?>"></td>
				</tr>
				<tr>
					<td>Permanent District</td>
					<td><input type="text" name="txtPDistrict" value="<?php $PDistrictID; ?>"></td>
				</tr>
				<tr>
					<td>Temporary Address</td>
					<td><input type="text" name="txtTAddress" value="<?php echo $TAddress; ?>"></td>
				</tr>
				<tr>
					<td>Temporary District</td>
					<td><input type="text" name="txtTDistrict" value="<?php echo $TDistrictID; ?>"></td>
				</tr>
				<tr>
					<td>Remarks</td>
					<td><input type="text" name="txtRemarks" value="<?php echo $Remarks; ?>"></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><button type="submit" id="btnSubmit">Submit</button> </td>
				</tr>
			</table>
		</form>
	</body>
</html>