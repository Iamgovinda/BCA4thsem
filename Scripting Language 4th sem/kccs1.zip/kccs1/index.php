<?php 
	require_once './includes/dbconfig.php';
	require_once './includes/helper.php';

	$sql = "SELECT s.roll_no, CONCAT(s.fname, ' ', s.mname, ' ', s.lname) as student_name, s.gender, CONCAT(d1.district_en, ', ', p1.province_en) AS permanent_address, CONCAT(d2.district_en, ', ', p2.province_en) AS temporary_address 
	FROM student s LEFT JOIN district d1 ON s.permanent_district_id = d1.id LEFT JOIN district d2 ON s.temporary_district_id = d2.id LEFT JOIN province p1 ON d1.province_id = p1.id LEFT JOIN province p2 ON d2.province_id = p2.id 
	WHERE s.roll_no =$myRollNo";

	$data = SelectQuery($sql);
	$row = $data[0];
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Our first PHP script</title>
	</head>
	<body>

		<?php include('./includes/menu.php'); ?>

		<h1>Welcome to my Home Page<h1>
			<h5>Details about me<h5>
			<table width="60%">
				<tr>
					<td width="20%">Roll No</td>
					<td width="80%"><?php echo $row['roll_no']; ?></td>
				</tr>
				<tr>
					<td>Name</td>
					<td><?php echo $row['student_name']; ?></td>
				</tr>
				<tr>
					<td>Gender</td>
					<td><?php echo $row['gender']; ?></td>
				</tr>
				<tr>
					<td>Permanent Address</td>
					<td><?php echo $row['permanent_address']; ?></td>
				</tr>
				<tr>
					<td>Temporary Address</td>
					<td><?php echo $row['temporary_address']; ?></td>
				</tr>
			</table>
	</body>
</html>