#include<stdio.h>
int main()
{
    printf("SN\tx1\tfx1\tx2\tfx2\tx3\tfx3");
}